Source Code findet sich unter:
https://github.com/nhoelzl/object_localisation